#引用 arules 模組
install.packages("arules")
install.packages("arulesViz")
library(arules)
library(arulesViz)
#產品編號7439,
#超微米潔顏乳 Shishedo Perfect Whip Cleansing Foam，洗顏系列
#開啟正負向效果59+膚質6+成分8的原始檔案，使用者共有3336，並給每個欄位命名
face3860 = read.csv("7439.csv",header=FALSE,col.names=c("心得編號","產品編號","年齡","保濕","溫和低刺激","會回購","明亮與透亮","價格實在","不引起過敏","好吸收","清爽","不黏膩","服貼","滋潤","不油膩","柔嫩","不致痘","光滑","水亮","美白","舒緩","香氣宜人","無負擔","彈力","不致粉刺","修護","不緊繃","鎮定","用量省","好上手","清新","易洗淨","清涼感","評分","skin","春","夏","秋","冬","保濕力劣","刺激性強","昂貴","引起過敏","吸收劣","非清爽","黏膩","油膩","致痘","美白無效","氣味劣","緊繃","用量大","洗淨劣","控油優","控油劣","非泛白","粉刺減少","暗沉","非暗沉","淡化黑眼圈劣","細紋淡化","淡化細紋差","防曬優","防曬差","易推勻","難推勻","不回購","無效果","硬脂酸","氫氧化鉀","甘油","十二酸","乙醇","丁二醇","維生素E","苯甲酸甲脂"))

#從資料框架或矩陣中選擇行與列的資料，選擇條件，過濾不須要的年齡
face3860 = subset(face3860,subset=(年齡<90 & 年齡>10 ))
#face7060 = subset(face7060,subset=(skin=="混合性肌膚"))
#建立空陣列combinationSkin
#將膚質轉成布林值格式，混合性肌膚為1，其它膚質為0，例如油性肌膚為0
combinationSkin = nrow(face3860)   
skin = face3860$skin
combinationSkin[skin=="混合性肌膚"] = 1#新增欄位為combinationSkin，值改為1
combinationSkin[skin=="油性肌膚"] = 0
combinationSkin[skin=="乾性肌膚"] = 0
combinationSkin[skin=="先天過敏性肌膚"] = 0
combinationSkin[skin=="敏感性肌膚"] = 0
combinationSkin[skin=="普通性肌膚"] = 0
combinationSkin #查看轉為010101的結果
data = cbind(face3860,combinationSkin) #資料合併，新的空陣列加入。
#從資料框架或矩陣中選擇行與列的資料，選擇條件正負向效果、膚質、成分，select選擇欄位
newface3860=subset(data,select=c("保濕","溫和低刺激","會回購","明亮與透亮","價格實在","不引起過敏","好吸收","清爽","不黏膩","服貼","滋潤","不油膩","柔嫩","不致痘","光滑","水亮","美白","舒緩","香氣宜人","無負擔","彈力","不致粉刺","修護","不緊繃","鎮定","用量省","好上手","清新","易洗淨","清涼感","刺激性強","昂貴","引起過敏","吸收劣","非清爽","黏膩","油膩","致痘","美白無效","氣味劣","緊繃","用量大","洗淨劣","控油優","控油劣","非泛白","粉刺減少","暗沉","非暗沉","淡化黑眼圈劣","細紋淡化","淡化細紋差","防曬優","防曬差","易推勻","難推勻","不回購","無效果","硬脂酸","氫氧化鉀","甘油","十二酸","乙醇","丁二醇","維生素E","苯甲酸甲脂","combinationSkin"))
class(newface3860) #資料結構[1] "data.frame"
newface3860= newface3860[complete.cases(newface3860),]
is.na(newface3860)
#資料檔每一列為 0 或 1 的 transaction 紀錄
mydata <- as.matrix(newface3860)
class(mydata)
nash <- as(mydata,"transactions")
summary(nash)
#檢視各單一項目出現的頻率
sort(itemFrequency(nash),decreasing=T)
itemFrequencyPlot(nash,support=0.01,cex.names=0.8)
#使用 apriori 函數  支持度、信賴度自行設定 lift增益值
rules=apriori(nash,parameter=list(support=0.05,confidence=0.55))  
rules
summary(rules)
plot(rules)
inspect(head(sort(rules, by = "lift"), n = 100))
plot(rules)
plot(rules, method = "grouped")
#最後選擇你想了解的情況與有興趣的規則找出顯著規則(增益大於1)，並排序
#例如混合性肌膚使用者(combinationSkin)
#想知道他們購買且使用這個產品加上此產品成分會得到什麼感覺(效果)
rulesown <- subset(rules,subset=rhs %in% "combinationSkin"&lift>1)
rulesown
summary(rulesown)
inspect(head(sort(rulesown, by = "lift"), n = 200))
plot(rulesown)
plot(rulesown, method = "grouped")



